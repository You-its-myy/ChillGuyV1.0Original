TR=Bu oyun Chill Guy V1.0 (Original) olarak yayımlanmıştır.
Tüm hakları saklıdır.

Oyunu kullanmak (oynamak) serbesttir.

Bu dosyanın veya oyunun kopyalanması, çoğaltılması, paylaşılması, yeniden dağıtılması yasaktır.

Oyunun veya içeriğinin herhangi bir kısmında değişiklik, modifikasyon, tersine mühendislik, edit veya yeniden yapım yapmak kesinlikle yasaktır.

Oyunun veya içeriğinin ticari veya kişisel amaçla yeniden dağıtımı izinsiz yapılamaz.

Yasal izin verilmedikçe kaynak kodu, varlıklar (grafik, ses, metin) veya oyun dosyaları kopyalanamaz veya yeniden kullanılamaz.

Bişey yapılcaksa Discord:ekmekreisyansanayi ulaşınız.

Telif hakkı ihlali durumunda yasal işlem uygulanabilir.

© 2025 Chill Guy V1.0 — Original
Tüm hakları saklıdır.


En=This game is published as Chill Guy V1.0 (Original).
All rights reserved.

Using (playing) the game is permitted.

Copying, reproducing, sharing, or redistributing this file or the game is prohibited.

Modifying, editing, reverse engineering, or remaking any part of the game or its content is strictly prohibited.

Unauthorized redistribution of the game or its content for commercial or personal purposes is not allowed.

Source code, assets (graphics, audio, text), or game files may not be copied or reused without express permission.

Legal action may be taken in case of copyright infringement.

© 2025 Chill Guy V1.0 — Original
All rights reserved.