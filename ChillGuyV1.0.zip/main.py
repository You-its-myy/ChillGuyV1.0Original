import pygame
import sys
import os
import random 
import traceback 
import tkinter as tk 
from tkinter import messagebox, scrolledtext 
import math # <--- YENİ: Uzaklık hesaplamak için eklendi

# --- TKINTER HATA PENCERESİ FONKSİYONU ---
def show_error_window(error_message):
    """
    Oyun çöktüğünde Tkinter ile detaylı hata penceresi açar.
    Hata mesajını kopyalama imkanı sunar.
    """
    root = tk.Tk()
    root.withdraw()
    root.title("Kritik Oyun Hatası!")
    root.geometry("600x400")
    
    tk.Label(root, text="Oyun beklenmedik bir hatayla çöktü.", 
             fg="red", font=("Helvetica", 12, "bold")).pack(pady=10)
    
    tk.Label(root, text="Lütfen aşağıdaki hatayı geliştiriciye iletin:").pack(pady=5)
    
    trace_text = scrolledtext.ScrolledText(root, wrap=tk.WORD, height=15, width=70)
    trace_text.insert(tk.INSERT, error_message)
    trace_text.config(state=tk.DISABLED)
    trace_text.pack(padx=10)
    
    def copy_to_clipboard():
        root.clipboard_clear()
        root.clipboard_append(error_message)
        root.update()
        messagebox.showinfo("Kopyalandı", "Hata detayları panoya kopyalandı!")

    copy_button = tk.Button(root, text="Hatayı Kopyala", command=copy_to_clipboard)
    copy_button.pack(pady=10)
    
    root.deiconify()
    root.mainloop()


# --- PYGAME İLK BAŞLANGIÇ AYARLARI ---
pygame.init()
pygame.mixer.init() 

# >>> TAM EKRAN BAŞLANGIÇ AYARI <<<
TAM_EKRAN_BASLANGIC = True 

GENISLIK = 1000
YUKSEKLIK = 600

# EKRAN YÜZEYİNİ OLUŞTURMA
if TAM_EKRAN_BASLANGIC:
    bilgi = pygame.display.Info()
    GENISLIK = bilgi.current_w
    YUKSEKLIK = bilgi.current_h
    EKRAN = pygame.display.set_mode((GENISLIK, YUKSEKLIK), pygame.FULLSCREEN)
else:
    EKRAN = pygame.display.set_mode((GENISLIK, YUKSEKLIK))


pygame.display.set_caption("Chill Guy V1.0 Original (Top-Down)") 
SAAT = pygame.time.Clock()

# --- Klasör Sabitleri ---
SPRITE_DIR = 'sprite'
SOUND_DIR = 'sound'

# --- Renkler ve Fontlar ---
BEYAZ = (255, 255, 255)
SIYAH = (0, 0, 0)
SARI = (255, 255, 0) 
MAVI = (0, 100, 200) 
KIRMIZI_DEBUG = (255, 0, 0) 
YESIL = (0, 200, 0)

FONT = pygame.font.Font(None, 40)
KUCUK_FONT = pygame.font.Font(None, 30)
BUYUK_FONT = pygame.font.Font(None, 60)

# --- Sabitler ---
ENVANTER_SLOT_SAYISI = 4    
STACK_MAX = 12              
INVENTORY_W = 240           
INVENTORY_H = 60            
HOBJECT_BOYUT = (70, 45) 
MAGAZA_BOYUT = (80, 120) 

# --- Kaynak Yükleme Fonksiyonları ---

def dosya_yolu_olustur(klasor, dosya_adi):
    return os.path.join(klasor, dosya_adi)

def resim_yukle(dosya_adi, boyut=None, klasor=SPRITE_DIR):
    yol = dosya_yolu_olustur(klasor, dosya_adi)
    try:
        resim = pygame.image.load(yol).convert_alpha()
        
        if dosya_adi == "e.png":
            resim = pygame.transform.scale(resim, (INVENTORY_W, INVENTORY_H))
        elif dosya_adi == "HObject.png":
            resim = pygame.transform.scale(resim, HOBJECT_BOYUT)
        elif dosya_adi == "magaza.png":
            resim = pygame.transform.scale(resim, MAGAZA_BOYUT) 
        elif boyut:
            resim = pygame.transform.scale(resim, boyut)
            
        return resim
    except pygame.error as e:
        print(f"HATA! Resim '{yol}' yüklenemedi.")
        
        if dosya_adi.startswith(('dur', 'vur', 'yuru', 'magaza')):
             raise ValueError(f"Kritik animasyon/obje eksik/bozuk: {dosya_adi}") from e 

        if dosya_adi == "HObject.png":
             yuzey = pygame.Surface(HOBJECT_BOYUT, pygame.SRCALPHA)
        elif dosya_adi == "magaza.png":
             yuzey = pygame.Surface(MAGAZA_BOYUT, pygame.SRCALPHA)
        elif dosya_adi == "e.png":
             yuzey = pygame.Surface((INVENTORY_W, INVENTORY_H), pygame.SRCALPHA)
        else:
             yuzey = pygame.Surface(boyut or (50, 50), pygame.SRCALPHA)
             
        yuzey.fill((255, 0, 255, 128)) 
        return yuzey

def ses_yukle(dosya_adi, klasor=SOUND_DIR):
    yol = dosya_yolu_olustur(klasor, dosya_adi)
    try:
        return pygame.mixer.Sound(yol)
    except pygame.error:
        print(f"UYARI: Ses '{yol}' yüklenemedi.")
        return None 

# ----------------------------------------------------
## 📥 Kaynak Yükleme ve Boyutlar
# ----------------------------------------------------

PLAYER_BOYUT = (60, 60)
ZEMIN_ANIM_BOYUT = (100, 100) 

try:
    PLAYER_ANIMS = {
        "durma": [resim_yukle(f"dur{i}.png", PLAYER_BOYUT) for i in range(1, 3)], 
        "vurma": [resim_yukle(f"vur{i}.png", PLAYER_BOYUT) for i in range(1, 3)], 
        "yurume": [resim_yukle(f"yuru{i}.png", PLAYER_BOYUT) for i in range(1, 5)], 
    }
    
    for key, anim_list in PLAYER_ANIMS.items():
        if not anim_list:
             raise ValueError(f"'{key}' animasyon listesi boş. Lütfen dosyaları kontrol edin.")

    MAGAZA_RESIM = resim_yukle("magaza.png")

except Exception as e:
    pygame.quit()
    show_error_window(f"Başlangıç Hatası:\n{traceback.format_exc()}")
    sys.exit()


CAN_BARLARI = {
    4: resim_yukle("bar1.png", (100, 20)), 
    3: resim_yukle("bar2.png", (100, 20)), 
    2: resim_yukle("bar3.png", (100, 20)), 
    1: resim_yukle("bar4.png", (100, 20)), 
    0: resim_yukle("bar5.png", (100, 20)), 
}

HOBJECT_RESIM = resim_yukle("HObject.png")
ENVANTER_SLOT_RESMI = resim_yukle("e.png") 
ESYA_RESMI_TAS = pygame.transform.scale(HOBJECT_RESIM, (30, 20)) 

ZEMIN_ANIMS = [
    resim_yukle("yer1.png", ZEMIN_ANIM_BOYUT),
    resim_yukle("yer2.png", ZEMIN_ANIM_BOYUT)
]

SESLER = {
    "vur": ses_yukle("vur1.mp3"),
    "obje_olum": ses_yukle("vur2obje.mp3"),
    "player_olum": ses_yukle("death.mp3"),
}

try:
    pygame.mixer.music.load(dosya_yolu_olustur(SOUND_DIR, "normal.mp3"))
except pygame.error:
    pass


# ----------------------------------------------------
## 🧑‍💻 SINIFLAR
# ----------------------------------------------------

class ZeminAnimasyonu(pygame.sprite.Sprite):
    def __init__(self, x, y):
        super().__init__()
        self.anims = ZEMIN_ANIMS
        self.anim_frame = 0
        self.anim_hizi = 150 
        self.son_guncelleme = pygame.time.get_ticks()
        self.image = self.anims[0] if self.anims else pygame.Surface(ZEMIN_ANIM_BOYUT) 
        self.rect = self.image.get_rect(topleft=(x, y))

    def update(self):
        if not self.anims: return
        simdi = pygame.time.get_ticks()
        if simdi - self.son_guncelleme > self.anim_hizi:
            self.son_guncelleme = simdi
            self.anim_frame = (self.anim_frame + 1) % len(self.anims)
            self.image = self.anims[self.anim_frame]

class Player(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.anims = PLAYER_ANIMS
        self.durum = "durma"
        self.anim_frame = 0
        self.anim_hizi = 80
        self.son_guncelleme = pygame.time.get_ticks()

        self.image = self.anims["durma"][0]
            
        self.rect = self.image.get_rect(center=(GENISLIK // 2, YUKSEKLIK // 2))
        self.hiz = 5
        self.facing_right = True 

        self.max_hp = 4
        self.hp = 4
        self.vuruyor = False
        self.son_vurma = 0
        self.vurma_gecikmesi = 400 

        self.durma_baslangici = pygame.time.get_ticks()
        self.hasar_arasi_sayac = pygame.time.get_ticks()
        self.para = 0
        
    def animasyon_guncelle(self):
        simdi = pygame.time.get_ticks()
        anim_listesi = self.anims[self.durum]
        anim_uzunluk = len(anim_listesi)
        if anim_uzunluk == 0: return 
        
        if simdi - self.son_guncelleme > self.anim_hizi:
            self.son_guncelleme = simdi
            self.anim_frame = (self.anim_frame + 1) % anim_uzunluk
            temp_image = anim_listesi[self.anim_frame]
            
            if not self.facing_right:
                 self.image = pygame.transform.flip(temp_image, True, False)
            else:
                 self.image = temp_image

            if self.durum == "vurma" and self.anim_frame == len(self.anims["vurma"]) - 1:
                self.durum = "durma"
                self.vuruyor = False

    def hareket_et(self, tuslar):
        if self.vuruyor:
            self.durum = "vurma"
            return
        
        hareket_var = False
        if tuslar[pygame.K_a]:
            self.rect.x -= self.hiz
            self.facing_right = False 
            hareket_var = True
        if tuslar[pygame.K_d]:
            self.rect.x += self.hiz
            self.facing_right = True 
            hareket_var = True
        if tuslar[pygame.K_w]:
            self.rect.y -= self.hiz
            hareket_var = True
        if tuslar[pygame.K_s]:
            self.rect.y += self.hiz
            hareket_var = True
            
        self.durum = "yurume" if hareket_var else "durma" 
        
        if hareket_var:
            self.durma_baslangici = pygame.time.get_ticks()
            
        self.rect.x = max(0, min(self.rect.x, GENISLIK - self.rect.width))
        self.rect.y = max(0, min(self.rect.y, YUKSEKLIK - self.rect.height))

    def vur(self):
        simdi = pygame.time.get_ticks()
        if not self.vuruyor and simdi > self.son_vurma + self.vurma_gecikmesi:
            self.son_vurma = simdi
            self.vuruyor = True
            self.durum = "vurma"
            self.anim_frame = 0 
            if SESLER["vur"]:
                SESLER["vur"].play()
            
    def hasar_al(self, miktar):
        simdi = pygame.time.get_ticks()
        if simdi - self.hasar_arasi_sayac > 500:
            self.hp -= miktar
            self.hasar_arasi_sayac = simdi
            
            if self.hp <= 0:
                self.olum()

    def olum(self):
        if SESLER["player_olum"]:
            SESLER["player_olum"].play()
        self.respawn()

    def respawn(self):
        self.hp = self.max_hp
        self.rect.center = (GENISLIK // 2, YUKSEKLIK // 2)

    def ciz_can_bari(self):
        can_key = max(0, min(self.hp, 4))
        gosterilecek_resim = CAN_BARLARI.get(can_key)
        if gosterilecek_resim:
            EKRAN.blit(gosterilecek_resim, (10, 10)) 
    
    def ciz_para(self):
        para_yazisi = FONT.render(f"Para: {self.para} €", True, SARI)
        EKRAN.blit(para_yazisi, (GENISLIK - para_yazisi.get_width() - 10, 10))

    def update(self, *args): 
        self.animasyon_guncelle()
        
    def ciz_hitbox(self): 
        pygame.draw.rect(EKRAN, KIRMIZI_DEBUG, self.rect, 1)

class HObject(pygame.sprite.Sprite):
    def __init__(self, x, y, oyun_yonetimi):
        super().__init__()
        self.image = HOBJECT_RESIM
        self.rect = self.image.get_rect(center=(x, y)) 
        self.max_hp = 2 
        self.hp = 2
        self.son_hasar_zamani = pygame.time.get_ticks() 
        self.respawn_konum_ayarla() 
        self.oyun_yonetimi = oyun_yonetimi 

    def respawn_konum_ayarla(self):
        min_mesafe = 150 
        
        while True:
            x = random.randint(HOBJECT_BOYUT[0] // 2, GENISLIK - HOBJECT_BOYUT[0] // 2)
            y = random.randint(HOBJECT_BOYUT[1] // 2, YUKSEKLIK - HOBJECT_BOYUT[1] // 2)
            
            merkez_x = GENISLIK // 2
            merkez_y = YUKSEKLIK // 2
            
            mesafe = math.hypot(x - merkez_x, y - merkez_y) # math.hypot kullanıldı
            
            if mesafe > min_mesafe:
                self.rect.center = (x, y)
                break

    def respawn(self):
        self.hp = self.max_hp
        self.respawn_konum_ayarla() 
        self.son_hasar_zamani = pygame.time.get_ticks() 
        
    def ciz_can_bari(self):
        gosterilecek_resim = None
        
        if self.hp == 2:
            gosterilecek_resim = CAN_BARLARI.get(4) 
        elif self.hp == 1:
            gosterilecek_resim = CAN_BARLARI.get(2) 

        if gosterilecek_resim:
            EKRAN.blit(gosterilecek_resim, (self.rect.x - 25, self.rect.y - 35))

    def update(self, player):
        simdi = pygame.time.get_ticks()
        
        self.ciz_can_bari()
        
        if self.rect.colliderect(player.rect):
            if player.durum == "durma": 
                if simdi - player.durma_baslangici >= 2000: 
                    if simdi - self.son_hasar_zamani >= 2000: 
                        player.hasar_al(1)
                        self.son_hasar_zamani = simdi
                        player.durma_baslangici = simdi 

    def hasar_al(self, miktar):
        self.hp -= miktar
        if self.hp <= 0:
            if SESLER["obje_olum"]:
                SESLER["obje_olum"].play()
            
            self.oyun_yonetimi.envantere_ekle("tas", 1) 
            
            self.respawn() 

    def ciz_hitbox(self): 
        pygame.draw.rect(EKRAN, KIRMIZI_DEBUG, self.rect, 1)

class Magaza(pygame.sprite.Sprite):
    def __init__(self):
        super().__init__()
        self.image = MAGAZA_RESIM
        self.rect = self.image.get_rect(topright=(GENISLIK - 50, 50)) 
        self.aktif = False
        
    def etkilesim_ciz(self):
        yazi = FONT.render("E: Mağazayı Aç", True, SARI)
        EKRAN.blit(yazi, (self.rect.x - 30, self.rect.y + MAGAZA_BOYUT[1] + 5))
        
    def ciz_menu(self, player):
        menu_w, menu_h = 300, 200
        menu_x = GENISLIK // 2 - menu_w // 2
        menu_y = YUKSEKLIK // 2 - menu_h // 2
        
        pygame.draw.rect(EKRAN, SIYAH, (menu_x, menu_y, menu_w, menu_h))
        pygame.draw.rect(EKRAN, BEYAZ, (menu_x, menu_y, menu_w, menu_h), 3)
        
        baslik = FONT.render("MAĞAZA", True, BEYAZ)
        EKRAN.blit(baslik, (menu_x + menu_w // 2 - baslik.get_width() // 2, menu_y + 10))
        
        sat_butonu_rect = pygame.Rect(menu_x + 50, menu_y + 80, 200, 50)
        pygame.draw.rect(EKRAN, YESIL, sat_butonu_rect)
        sat_yazi = FONT.render("Envanteri Sat (5€/Taş)", True, BEYAZ)
        EKRAN.blit(sat_yazi, (sat_butonu_rect.x + 10, sat_butonu_rect.y + 12))
        
        cikis_yazi = KUCUK_FONT.render("ESC: Kapat", True, BEYAZ)
        EKRAN.blit(cikis_yazi, (menu_x + menu_w // 2 - cikis_yazi.get_width() // 2, menu_y + menu_h - 30))
        
        return sat_butonu_rect
    
    def ciz_hitbox(self): 
        pygame.draw.rect(EKRAN, KIRMIZI_DEBUG, self.rect, 1)

# ----------------------------------------------------
## ⚙️ OYUN YÖNETİMİ
# ----------------------------------------------------

class OyunYonetimi:
    def __init__(self):
        self.oyun_durumu = "ANA_MENU"
        self.oyna_butonu = None
        self.yukleme_baslangici = 0
        self.yukleme_suresi = 1500 
        self.hitbox_goster = False 
        self.magaza_acik = False
        self.sat_butonu_rect = None
        
        self.envanter = {
            "tas": [0] * ENVANTER_SLOT_SAYISI 
        }
        
        self.env_hud_x = GENISLIK // 2 - ENVANTER_SLOT_RESMI.get_width() // 2
        self.env_hud_y = YUKSEKLIK - ENVANTER_SLOT_RESMI.get_height() - 10

    def envantere_ekle(self, esya_adi, miktar):
        if esya_adi not in self.envanter:
            self.envanter[esya_adi] = [0] * ENVANTER_SLOT_SAYISI
        
        yeni_envanter = self.envanter[esya_adi]
        
        for i in range(ENVANTER_SLOT_SAYISI):
            if yeni_envanter[i] < STACK_MAX:
                bos_alan = STACK_MAX - yeni_envanter[i]
                eklenecek = min(miktar, bos_alan)
                yeni_envanter[i] += eklenecek
                miktar -= eklenecek
                
                if miktar == 0:
                    break
        
        self.envanter[esya_adi] = yeni_envanter

    def taslari_sat(self, player):
        toplam_tas = sum(self.envanter["tas"])
        fiyat = 5 
        kazanc = toplam_tas * fiyat
        
        player.para += kazanc
        
        self.envanter["tas"] = [0] * ENVANTER_SLOT_SAYISI
        
        self.magaza_acik = False
        print(f"{toplam_tas} taş satıldı, {kazanc} € kazanıldı. Yeni bakiye: {player.para} €")
        
    
    def yukleniyor_ekrani_ciz(self):
        simdi = pygame.time.get_ticks()
        gecen_sure = simdi - self.yukleme_baslangici
        ilerleme_orani = min(1.0, gecen_sure / self.yukleme_suresi)

        EKRAN.fill(SIYAH)
        
        baslik = FONT.render("Chill Guy Yükleniyor...", True, BEYAZ)
        EKRAN.blit(baslik, (GENISLIK // 2 - baslik.get_width() // 2, 200))
        
        BAR_GENISLIK = min(600, GENISLIK - 100) 
        BAR_YUKSEKLIK = 10
        BAR_X = GENISLIK // 2 - BAR_GENISLIK // 2
        BAR_Y = YUKSEKLIK // 2 + 50
        
        cerceve_rect = pygame.Rect(BAR_X, BAR_Y, BAR_GENISLIK, BAR_YUKSEKLIK)
        pygame.draw.rect(EKRAN, BEYAZ, cerceve_rect, 2) 

        cizgi_genislik = int(BAR_GENISLIK * ilerleme_orani)
        cizgi_rect = pygame.Rect(BAR_X, BAR_Y, cizgi_genislik, BAR_YUKSEKLIK)
        pygame.draw.rect(EKRAN, MAVI, cizgi_rect) 

        if ilerleme_orani >= 1.0:
            self.baslat()
    
    def ana_menu_ciz(self):
        EKRAN.fill(SIYAH)
        
        baslik = FONT.render("Chill Guy V1.0 Original", True, BEYAZ)
        EKRAN.blit(baslik, (GENISLIK // 2 - baslik.get_width() // 2, 150))
        
        self.oyna_butonu = pygame.Rect(GENISLIK // 2 - 120, YUKSEKLIK // 2, 240, 60)
        pygame.draw.rect(EKRAN, (0, 150, 0), self.oyna_butonu, border_radius=10)
        
        oyna_yazi = FONT.render("OYUNU BAŞLAT", True, BEYAZ)
        EKRAN.blit(oyna_yazi, (self.oyna_butonu.x + 20, self.oyna_butonu.y + 15))


    def baslat(self):
        pygame.mixer.music.play(-1) 

        self.player = Player()
        
        self.hobject_grup = pygame.sprite.Group()
        self.hobject_grup.add(HObject(0, 0, self)) 
        self.hobject_grup.add(HObject(0, 0, self)) 
        
        self.magaza = Magaza()
        self.magaza_grup = pygame.sprite.GroupSingle(self.magaza)

        self.zemin_grup = pygame.sprite.Group()
        for y in range(0, YUKSEKLIK, ZEMIN_ANIM_BOYUT[1]):
            for x in range(0, GENISLIK, ZEMIN_ANIM_BOYUT[0]):
                self.zemin_grup.add(ZeminAnimasyonu(x, y))
            
        self.oyuncu_grup = pygame.sprite.GroupSingle(self.player)
        
        self.oyun_durumu = "OYUN"
        self.vurma_hasari = 1

    def ciz_envanter(self):
        self.env_hud_x = GENISLIK // 2 - ENVANTER_SLOT_RESMI.get_width() // 2
        self.env_hud_y = YUKSEKLIK - ENVANTER_SLOT_RESMI.get_height() - 10
        
        EKRAN.blit(ENVANTER_SLOT_RESMI, (self.env_hud_x, self.env_hud_y))
        
        TEK_SLOT_W = ENVANTER_SLOT_RESMI.get_width() // ENVANTER_SLOT_SAYISI 
        TEK_SLOT_H = ENVANTER_SLOT_RESMI.get_height()
        
        for i in range(ENVANTER_SLOT_SAYISI):
            if i < len(self.envanter["tas"]):
                tas_sayisi = self.envanter["tas"][i]
                
                if tas_sayisi > 0:
                    slot_baslangic_x = self.env_hud_x + (i * TEK_SLOT_W) 
                    
                    esya_x = slot_baslangic_x + (TEK_SLOT_W // 2) - (ESYA_RESMI_TAS.get_width() // 2)
                    esya_y = self.env_hud_y + (TEK_SLOT_H // 2) - (ESYA_RESMI_TAS.get_height() // 2)
                    EKRAN.blit(ESYA_RESMI_TAS, (esya_x, esya_y))
                    
                    sayi_yuzeyi = KUCUK_FONT.render(str(tas_sayisi), True, SARI)
                    sayi_x = slot_baslangic_x + TEK_SLOT_W - sayi_yuzeyi.get_width() - 3
                    sayi_y = self.env_hud_y + TEK_SLOT_H - sayi_yuzeyi.get_height() + 5
                    
                    EKRAN.blit(sayi_yuzeyi, (sayi_x, sayi_y))


    def oyun_dongusu(self):
        EKRAN.fill(SIYAH) 
        
        tuslar = pygame.key.get_pressed()
        
        # --- Güncelleme ---
        if not self.magaza_acik:
            self.player.hareket_et(tuslar) 
        self.zemin_grup.update()
        self.oyuncu_grup.update()
        self.hobject_grup.update(self.player)

        # Vurma Çarpışma Kontrolü
        if self.player.vuruyor: 
            vurma_rect_genislik = 30
            vurma_rect_yukseklik = self.player.rect.height
            
            if self.player.facing_right:
                vurma_rect = pygame.Rect(self.player.rect.right, self.player.rect.y, vurma_rect_genislik, vurma_rect_yukseklik)
            else:
                vurma_rect = pygame.Rect(self.player.rect.left - vurma_rect_genislik, self.player.rect.y, vurma_rect_genislik, vurma_rect_yukseklik)

            for obje in self.hobject_grup:
                if vurma_rect.colliderect(obje.rect):
                    obje.hasar_al(self.vurma_hasari) 
        
        # --- Çizim ---
        self.zemin_grup.draw(EKRAN)
        self.hobject_grup.draw(EKRAN)
        self.magaza_grup.draw(EKRAN)
        self.oyuncu_grup.draw(EKRAN)
        
        # Mağaza etkileşim kontrolü
        # DÜZELTME: distance_to yerine math.hypot kullanılıyor.
        merkez_dx = self.player.rect.centerx - self.magaza.rect.centerx
        merkez_dy = self.player.rect.centery - self.magaza.rect.centery
        magaza_ile_mesafe = math.hypot(merkez_dx, merkez_dy)

        if magaza_ile_mesafe < 100:
            if not self.magaza_acik:
                self.magaza.etkilesim_ciz()
        
        # HUD Çizimi
        self.player.ciz_can_bari() 
        self.player.ciz_para()
        self.ciz_envanter() 
        
        # Hitbox Çizimi (F3 aktifse)
        if self.hitbox_goster:
            self.player.ciz_hitbox()
            for obje in self.hobject_grup:
                obje.ciz_hitbox()
            self.magaza.ciz_hitbox()

        # Mağaza Menüsü Çizimi (Mağaza açıksa)
        if self.magaza_acik:
            self.sat_butonu_rect = self.magaza.ciz_menu(self.player)


    def calistir(self):
        global GENISLIK, YUKSEKLIK, EKRAN
        
        try: 
            while True:
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        pygame.quit()
                        sys.exit()
                    
                    if self.oyun_durumu == "ANA_MENU":
                        if event.type == pygame.MOUSEBUTTONDOWN and self.oyna_butonu and self.oyna_butonu.collidepoint(event.pos):
                            self.oyun_durumu = "YUKLENIYOR"
                            self.yukleme_baslangici = pygame.time.get_ticks()
                    
                    elif self.oyun_durumu == "OYUN":
                        # 1. Fare tıklaması (Vurma veya Satın Alma/Satma)
                        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                            if self.magaza_acik and self.sat_butonu_rect and self.sat_butonu_rect.collidepoint(event.pos):
                                self.taslari_sat(self.player)
                            elif not self.magaza_acik:
                                self.player.vur()
                        
                        # 2. Tuşa basma
                        if event.type == pygame.KEYDOWN:
                            # F3 Tuşu Düzeltmesi
                            if event.key == pygame.K_F3: 
                                self.hitbox_goster = not self.hitbox_goster
                            
                            # F4 Tuşu Düzeltmesi
                            if event.key == pygame.K_F4: 
                                if EKRAN.get_flags() & pygame.FULLSCREEN:
                                    GENISLIK, YUKSEKLIK = 1000, 600
                                    EKRAN = pygame.display.set_mode((GENISLIK, YUKSEKLIK))
                                    self.baslat() 
                                else:
                                    bilgi = pygame.display.Info()
                                    GENISLIK = bilgi.current_w
                                    YUKSEKLIK = bilgi.current_h
                                    EKRAN = pygame.display.set_mode((GENISLIK, YUKSEKLIK), pygame.FULLSCREEN)
                                    self.baslat()
                            
                            if event.key == pygame.K_ESCAPE:
                                self.magaza_acik = False
                            
                            if event.key == pygame.K_e and not self.magaza_acik:
                                # "E" tuşu ile mağazayı açma
                                merkez_dx = self.player.rect.centerx - self.magaza.rect.centerx
                                merkez_dy = self.player.rect.centery - self.magaza.rect.centery
                                magaza_ile_mesafe = math.hypot(merkez_dx, merkez_dy)
                                
                                if magaza_ile_mesafe < 100:
                                    self.magaza_acik = True

                if self.oyun_durumu == "ANA_MENU":
                    self.ana_menu_ciz()
                elif self.oyun_durumu == "YUKLENIYOR":
                    self.yukleniyor_ekrani_ciz()
                elif self.oyun_durumu == "OYUN":
                    self.oyun_dongusu()

                pygame.display.flip()
                SAAT.tick(60)

        except Exception:
            pygame.quit()
            error_message = traceback.format_exc()
            show_error_window(error_message)
            sys.exit()

if __name__ == "__main__":
    oyun_yonetimi = OyunYonetimi()
    oyun_yonetimi.calistir()